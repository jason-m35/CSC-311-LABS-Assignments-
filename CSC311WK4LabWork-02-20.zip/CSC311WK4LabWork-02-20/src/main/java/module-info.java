module edu.farmingdale.csc311wk4labwork0220 {
    requires javafx.controls;
    requires javafx.fxml;


    opens edu.farmingdale.csc311wk4labwork0220 to javafx.fxml;
    exports edu.farmingdale.csc311wk4labwork0220;
}