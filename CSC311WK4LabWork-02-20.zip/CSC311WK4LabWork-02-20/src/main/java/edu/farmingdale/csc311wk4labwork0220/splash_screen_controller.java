package edu.farmingdale.csc311wk4labwork0220;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;

import java.io.IOException;

public class splash_screen_controller {
    @FXML
    private Label welcomeText;

    @FXML
    void moveToNewScreen(MouseEvent event) throws IOException {
        Scene scene = welcomeText.getScene();
        FXMLLoader loader = new FXMLLoader(getClass().getResource("splash_screen.fxml"));
        scene.setRoot(loader.load());
    }
}