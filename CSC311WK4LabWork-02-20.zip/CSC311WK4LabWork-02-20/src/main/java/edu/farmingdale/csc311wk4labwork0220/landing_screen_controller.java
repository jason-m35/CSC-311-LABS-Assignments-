package edu.farmingdale.csc311wk4labwork0220;

public class landing_screen_controller {
}
